const express = require('express');
const User = require('../models/User');
const Enrollment = require('../models/Enrollment');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Get all users (admin)
router.get('/users', authMiddleware, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Access denied' });
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all enrollments (admin)
router.get('/enrollments', authMiddleware, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Access denied' });
  try {
    const enrollments = await Enrollment.find().populate('student', 'name').populate('course', 'title');
    res.json(enrollments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;