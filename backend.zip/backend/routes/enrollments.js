const express = require('express');
const Enrollment = require('../models/Enrollment');
const Course = require('../models/Course');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Enroll in course (student)
router.post('/', authMiddleware, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Access denied' });
  const { course } = req.body;
  try {
    const existing = await Enrollment.findOne({ student: req.user._id, course });
    if (existing) return res.status(400).json({ error: 'Already enrolled' });
    const enrollment = new Enrollment({ student: req.user._id, course });
    await enrollment.save();
    res.status(201).json(enrollment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get my enrollments (student)
router.get('/my', authMiddleware, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Access denied' });
  try {
    const enrollments = await Enrollment.find({ student: req.user._id }).populate('course');
    res.json(enrollments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update progress (student)
router.put('/:id/progress', authMiddleware, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Access denied' });
  const { progress } = req.body;
  try {
    const enrollment = await Enrollment.findById(req.params.id);
    if (enrollment.student.toString() !== req.user._id) return res.status(403).json({ error: 'Access denied' });
    enrollment.progress = progress;
    if (progress === 100) enrollment.completed = true;
    await enrollment.save();
    res.json(enrollment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Download certificate (student)
router.post('/:id/certificate', authMiddleware, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Access denied' });
  try {
    const enrollment = await Enrollment.findById(req.params.id);
    if (enrollment.student.toString() !== req.user._id || !enrollment.completed) return res.status(403).json({ error: 'Access denied' });
    enrollment.certificateDownloaded = true;
    await enrollment.save();
    res.json({ message: 'Certificate downloaded' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;