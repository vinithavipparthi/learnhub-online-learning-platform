const express = require('express');
const Course = require('../models/Course');
const Section = require('../models/Section');
const Enrollment = require('../models/Enrollment');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Get all courses
router.get('/', async (req, res) => {
  try {
    const courses = await Course.find().populate('teacher', 'name').populate('sections');
    res.json(courses);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get course by id
router.get('/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id).populate('teacher', 'name').populate('sections');
    res.json(course);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create course (teacher)
router.post('/', authMiddleware, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Access denied' });
  const { title, description, price, category } = req.body;
  try {
    const course = new Course({ title, description, teacher: req.user._id, price, category });
    await course.save();
    res.status(201).json(course);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update course (teacher/admin)
router.put('/:id', authMiddleware, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (req.user.role !== 'admin' && course.teacher.toString() !== req.user._id) return res.status(403).json({ error: 'Access denied' });
    const updated = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete course (teacher/admin)
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (req.user.role !== 'admin' && course.teacher.toString() !== req.user._id) return res.status(403).json({ error: 'Access denied' });
    // Check if enrolled students
    const enrollments = await Enrollment.find({ course: req.params.id });
    if (enrollments.length > 0) {
      return res.status(400).json({ error: 'Cannot delete course with enrolled students' });
    }
    await Course.findByIdAndDelete(req.params.id);
    res.json({ message: 'Course deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add section to course (teacher)
router.post('/:id/sections', authMiddleware, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (course.teacher.toString() !== req.user._id) return res.status(403).json({ error: 'Access denied' });
    const { title, content } = req.body;
    const section = new Section({ title, content, course: req.params.id });
    await section.save();
    await Course.findByIdAndUpdate(req.params.id, { $push: { sections: section._id } });
    res.status(201).json(section);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;